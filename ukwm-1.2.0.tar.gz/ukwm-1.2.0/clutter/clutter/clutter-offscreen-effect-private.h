#ifndef __CLUTTER_OFFSCREEN_EFFECT_PRIVATE_H__
#define __CLUTTER_OFFSCREEN_EFFECT_PRIVATE_H__

#include <clutter/clutter-offscreen-effect.h>

G_BEGIN_DECLS

G_END_DECLS

#endif /* __CLUTTER_OFFSCREEN_EFFECT_PRIVATE_H__ */
